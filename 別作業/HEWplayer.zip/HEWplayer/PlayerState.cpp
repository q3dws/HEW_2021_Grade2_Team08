#include "PlayerState.h"

PlayerIdle::PlayerIdle(Player* player)
{
}

PlayerIdle::~PlayerIdle()
{
}

void PlayerIdle::Initialize(Player* player)
{
}

void PlayerIdle::HandleInput(Player* player)
{
}

void PlayerIdle::Update(Player* player)
{
}
